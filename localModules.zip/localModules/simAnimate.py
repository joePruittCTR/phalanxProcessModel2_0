import salabim as sb
import random # Needed for random.expovariate if AnimatedSource wasn't inheriting fully
# Import the canonical SimulationParameters and the setup helper from the core simulation logic
from . import _03simProcess as sim_process # Assuming 03simProcess.py is in the same directory or a package

# Define a specific Customer class for animation to give it a visual representation
class AnimatedCustomer(sim_process.Customer):
    """
    Extends the base Customer class to add visual representation and movement
    for Salabim animation.
    """
    def setup(self, handler_resource):
        super().setup(handler_resource) # Call the parent's setup (enters queue)
        # Add visual representation for the customer
        # Initial position at the source/entrance to the queue
        self.animation_object = sb.Animate3d(
            'sphere.fbx', # A simple 3D model (Salabim provides some, or use your own)
            x=self.env.q.x - 2, y=self.env.q.y, z=self.env.q.z, # Start slightly before the queue
            scale=0.1, color='green',
            parent=self.env.animation_root # Parent to animation root for global positioning
        )

    def process(self):
        # Animate movement to the queue
        yield self.animate(
            x=self.env.q.x, y=self.env.q.y, z=self.env.q.z,
            duration=0.5, # Time to move to queue
            _component=self.animation_object
        )

        # Customer is now in the queue, waiting for handler
        # The parent is still animation_root, but its x/y/z are now at queue start

        self.service_start_time = self.env.now()
        self.handler_resource.request() # Request a handler (server)

        # Animate movement from queue to handler (server)
        yield self.animate(
            x=self.handler_resource.x, y=self.handler_resource.y, z=self.handler_resource.z,
            duration=0.5, # Time to move to server
            _component=self.animation_object,
            # color='orange' # Change color while being processed
        )

        yield self.hold(self.env.sim_params.serverTime) # Hold for the calculated server time

        self.handler_resource.release() # Release the handler
        self.env.customer_service_monitor.tally(self.env.now() - self.service_start_time) # Monitor service time
        self.leave(self.env.q) # Leave the queue

        self.env.customer_stay_monitor.tally(self.life_time()) # Monitor total time in system

        # Animate movement out of system (e.g., off-screen)
        yield self.animate(
            x=self.handler_resource.x + 2, y=self.handler_resource.y, z=self.handler_resource.z,
            duration=0.5,
            _component=self.animation_object,
            color='red' # Change color to indicate leaving
        )
        self.animation_object.remove() # Remove the animation object once it leaves


class AnimatedSource(sim_process.Source):
    """
    The Source component for the animated simulation.
    It inherits from the base Source and will correctly create AnimatedCustomer
    instances because _setup_simulation_components is now configured to pass
    AnimatedCustomer as the customer_type.
    """
    pass # No additional animation logic needed here, as it's handled by AnimatedCustomer


def run_animated_simulation(sim_params: sim_process.SimulationParameters):
    """
    Runs an animated simulation based on the provided SimulationParameters.

    Args:
        sim_params (sim_process.SimulationParameters): An object containing all simulation parameters.

    Returns:
        tuple: A tuple containing two lists of Salabim Monitor objects:
               - fileMonitorList: Monitors related to file processing (e.g., service time).
               - stayMonitorList: Monitors related to total time customers spend in the system.
    """
    # 1. Setup the Salabim Environment for animation
    env = sb.Environment(trace=False, do_animate=True)
    env.random_seed(sim_params.seed)

    # 2. Set up components using the flexible helper function from 03simProcess.py
    # This is the key change: we pass our animated customer and source classes.
    sim_objects = sim_process._setup_simulation_components(
        env,
        sim_params,
        customer_class=AnimatedCustomer,
        source_class=AnimatedSource
    )

    # Retrieve the Salabim objects we need for animation from the returned dictionary
    handler_resource = sim_objects['handler_resource']
    customer_queue = sim_objects['customer_queue']
    customer_stay_monitor = sim_objects['customer_stay_monitor']
    customer_service_monitor = sim_objects['customer_service_monitor']

    # 3. Add Animation Elements
    # Set coordinates for visual layout
    customer_queue.x = 2 # X-coordinate for queue
    customer_queue.y = 0 # Y-coordinate for queue
    customer_queue.z = 0 # Z-coordinate for queue (for 3D)

    handler_resource.x = 5 # X-coordinate for server
    handler_resource.y = 0 # Y-coordinate for server
    handler_resource.z = 0 # Z-coordinate for server

    # Queue visualization
    sb.AnimateQueue(customer_queue, x=customer_queue.x, y=customer_queue.y, id='customer_queue_vis',
                    spec='box', # or 'queue' if you want a visual queue
                    fill='lightblue', linecolor='blue',
                    text_offsetx=-0.5, text_offsety=-0.5,
                    title='Customer Queue', text_font_size=10,
                    x_content_gap=0.1, y_content_gap=0.1
                    )

    # Server visualization
    sb.AnimateResource(handler_resource, x=handler_resource.x, y=handler_resource.y, id='server_vis',
                       spec='cube', # or 'rectangle'
                       color='grey',
                       text_color='black',
                       text_anchor='n',
                       title='Server',
                       text_font_size=10
                       )

    # Monitor displays
    sb.AnimateMonitor(customer_queue.length, x=0, y=3, text_color='black', text_anchor='nw',
                      title='Queue Length', fmt='.0f', text_font_size=12)
    sb.AnimateMonitor(customer_stay_monitor, x=0, y=2.5, text_color='black', text_anchor='nw',
                      title='Avg Stay Time', fmt='.2f', text_font_size=12)
    sb.AnimateMonitor(customer_service_monitor, x=0, y=2, text_color='black', text_anchor='nw',
                      title='Avg Service Time', fmt='.2f', text_font_size=12)

    # Static text labels
    sb.AnimateText(x=0, y=3.5, text='Simulation Dashboard', text_color='darkblue', font_size=16, text_anchor='nw')
    sb.AnimateText(x=0, y=1.5, text=f'Sim Time: {sim_params.simTime} min', text_color='gray', font_size=10, text_anchor='nw')
    sb.AnimateText(x=0, y=1.2, text=f'FTEs: {sim_params.processingFte}', text_color='gray', font_size=10, text_anchor='nw')
    sb.AnimateText(x=0, y=0.9, text=f'IAT: {sim_params.iatCo} min', text_color='gray', font_size=10, text_anchor='nw')
    sb.AnimateText(x=0, y=0.6, text=f'CO Time: {sim_params.coMinutes} min', text_color='gray', font_size=10, text_anchor='nw')

    # 4. Run Simulation
    env.run(till=sim_params.simTime)

    # 5. Return Monitors
    fileMonitorList = [customer_service_monitor]
    stayMonitorList = [customer_stay_monitor]

    return fileMonitorList, stayMonitorList


# Example of how to use this module (for testing purposes, typically called from 01simStart.py)
if __name__ == '__main__':
    print("Running an animated test simulation from 04simAnimate.py __main__ block.")
    # Example parameter dictionary (this would normally come from 02simInput.py)
    test_params_dict = {
        'sim_time': 200, # Shorter time for animation demo
        'time_unit': 'minutes',
        'co_time': 8.0,
        'co_iat': 1.5, # Slower arrivals for clearer animation
        'processing_fte': 1.0,
        'processing_overhead': 0.10,
        'processing_efficiency': 0.90,
        'warmup_time': 0, # No warmup for animation
        'num_replications': 1,
        'seed': 42
    }

    # Create SimulationParameters object
    sim_params_instance = sim_process.SimulationParameters(test_params_dict)

    # Run the animated simulation
    service_monitors, stay_monitors = run_animated_simulation(sim_params_instance)

    # Access and print some results from the returned monitors
    if service_monitors:
        service_time_monitor = service_monitors[0]
        print(f"\nSimulation Results (Service Time):")
        print(f"  N: {service_time_monitor.n}")
        print(f"  Mean Service Time: {service_time_monitor.mean():.2f} minutes")
        print(f"  Max Service Time: {service_time_monitor.maximum():.2f} minutes")

    if stay_monitors:
        stay_time_monitor = stay_monitors[0]
        print(f"\nSimulation Results (Total Stay Time in System):")
        print(f"  N: {stay_time_monitor.n}")
        print(f"  Mean Stay Time: {stay_time_monitor.mean():.2f} minutes")
        print(f"  Max Stay Time: {stay_time_monitor.maximum():.2f} minutes")

